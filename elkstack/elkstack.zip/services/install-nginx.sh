#!/bin/bash
sudo apt update -y
sudo apt install nginx -y
#systemctl status nginx

