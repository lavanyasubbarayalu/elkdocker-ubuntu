#!/bin/bash
sudo apt update -y
sudo apt install nginx 
systemctl status nginx

